﻿// See https://aka.ms/new-console-template for more information
//Console.WriteLine("Hello, World!");
 Multiplos N3 = new Multiplos();
 N3.MULTIPO_DE_3();