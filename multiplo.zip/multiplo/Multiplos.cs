class Multiplos
{
    public int i{get;set;}
     public Multiplos()
    {
        this.i=i;
    }
    public void MULTIPO_DE_3()
    {
        for (int i= 0; i < 3000;i++)
        {
            if (i%3==0)
            {
                Console.WriteLine( i   +  "es multiplo de 3");
            }
        }
    }
}