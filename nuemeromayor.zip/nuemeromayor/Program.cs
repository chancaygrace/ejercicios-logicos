﻿// See https://aka.ms/new-console-template for more information
//Console.WriteLine("Hello, World!");
Numerom M=new Numerom(7,2);
M.Calcularmayor();