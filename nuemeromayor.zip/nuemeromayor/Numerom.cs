class Numerom
{
   
    public int valor1{get;set;}
    public int valor2{get;set;}

    public Numerom(int numero1,int numero2)
    {
        this.valor1=valor1;
        this.valor2=valor2;
    }
    public void Calcularmayor()
    {
        if (valor1>valor2)
        {
            Console.WriteLine("el numero mayor de estos numeros es :"+valor1);
           
        }    
        else
        {
            Console.WriteLine("el numero menor es  de estos numeros :"+valor2);
        }
            
    }
}