﻿// See https://aka.ms/new-console-template for more information
//Console.WriteLine("Hello, World!");
Suma_numeros SN =new Suma_numeros(2);
SN.Imprimir();