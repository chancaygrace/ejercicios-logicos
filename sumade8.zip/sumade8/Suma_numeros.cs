class Suma_numeros
{
    public int valor{get;set;}
    public Suma_numeros(int valor)
    {
        this.valor=valor;

    }
    public void Imprimir()
    {
        int suma=0;
    for (int i=0; i < 8; i++)
    {
        Console.WriteLine("*****INGRESE UN NUMERO*****");
        valor=int.Parse(Console.ReadLine());
        suma=suma+valor;
    }
         Console.WriteLine("LA SUMA DE LOS VALOR INGRESADOS ES :"+ suma);
         Console.ReadKey();
    } 
    
}