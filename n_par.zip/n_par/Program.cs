﻿// See https://aka.ms/new-console-template for more information
//Console.WriteLine("Hello, World!");
Npar P= new Npar(20);
P.Numero_Par();