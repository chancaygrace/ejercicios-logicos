class Npar
{
 
    public int numero{get;set;}
    

    public Npar(int numero)
    {
        this.numero=numero;
        
    }
    public void Numero_Par()
    {
        if (numero%2==0)
        {
            Console.WriteLine("*** Es Par ****");
           
        }    
        else
        {
            Console.WriteLine("** Es Impar **");
        }
    }   
}