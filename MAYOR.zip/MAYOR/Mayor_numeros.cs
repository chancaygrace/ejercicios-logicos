class Mayor_numeros
{
    public int valor1{get;set;}
    public int valor2{get;set;}
    public int valor3{get;set;}


    public Mayor_numeros(int valor1,int valoro2,int valor3)
    {
        this.valor1=valor1;
        this.valor2=valor2;
        this.valor3=valor3;
    }
    public void Calcular_Mayor()
    {
        if ((valor1>valor2)&&(valor1>valor3))
        {
            Console.WriteLine("--EL  numero mayor de los tres es:"+valor1);
           
        }    
        else if ((valor2>valor1)&&(valor2>valor3))
        {
            Console.WriteLine("----EL  numero mayor de los tres es :"+valor2);
        }
        else
        {
            Console.WriteLine("--EL  numero mayor de los tres es :"+valor3);
        }
    }   
}