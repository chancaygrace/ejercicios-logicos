﻿// See https://aka.ms/new-console-template for more information
//Console.WriteLine("Hello, World!");
Mayor_numeros N = new Mayor_numeros(2,4,8);
N.Calcular_Mayor();